﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FormatsEchanges_LibrairieClasses.TraitementsLots
{
    public interface ITraitementLot
    {
        public void Executer();
    }
}
